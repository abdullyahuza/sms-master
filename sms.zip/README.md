# sms-master
## A Nigeria base School Management System

## Features
### Admin
- Login
- Give admission
- Upload student(s) / view student / edit student
- Add staff / view staff / edit staff / delete staff 
- Add subject delete subject
- Add session / delete session
- Add class / delete class
- Upload result(s) - CSV
- Process single student result 
- Process entirer class result

### Staff
- Login
- view assigned class
- view class students
- upload result
- process student result
- process class result
- edit class student

#### Result template (not included here)
