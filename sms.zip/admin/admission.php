<?php 
	header("Location: ../error/404.php");
 ?>