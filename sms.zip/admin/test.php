<?php 
include '../functions.php';
echo checkPassport('TB/22/0001','../images/passports/');

 ?>