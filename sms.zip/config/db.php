<?php 
  $connection = mysqli_connect("localhost","root","","student_ms");
 ?>