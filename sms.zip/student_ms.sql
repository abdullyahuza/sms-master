-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 05, 2022 at 11:51 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_ms`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_subject`
--

CREATE TABLE `add_subject` (
  `add_subid` int(50) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_subject`
--

INSERT INTO `add_subject` (`add_subid`, `subject_name`, `code`) VALUES
(1, 'Mathematics', 'MATH'),
(2, 'English', 'ENG'),
(3, 'Physical Health Education', 'PHE'),
(4, 'Physics', 'PHYS'),
(5, 'Chemistry', 'CHEM'),
(10, 'Primary Science', 'PS'),
(16, 'Civic Education', 'CE'),
(17, 'Computer Studies', 'CS'),
(18, 'Data processing', 'DP'),
(23, 'Spelling', 'SP'),
(24, 'Basic Science', 'BS'),
(25, 'Basic Technology', 'BT'),
(26, 'Social Studies', 'SS'),
(27, 'Home Economics', 'HE'),
(28, 'Agricultural Science', 'AS'),
(29, 'Islamic Religious studies', 'IRS');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_name`, `password`, `isAdmin`) VALUES
(2, 'abdullyahuza', 'codediam', 1),
(3, 'tahirjamilu', '1234', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sesh2021_2022`
--

CREATE TABLE `sesh2021_2022` (
  `id` int(6) UNSIGNED NOT NULL,
  `session` varchar(20) NOT NULL,
  `subject_code` varchar(15) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `term` int(10) NOT NULL,
  `adNo` varchar(20) NOT NULL,
  `ca1` int(5) DEFAULT NULL,
  `ca2` int(5) DEFAULT NULL,
  `exams` int(5) DEFAULT NULL,
  `total` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sesh2021_2022`
--

INSERT INTO `sesh2021_2022` (`id`, `session`, `subject_code`, `subject_name`, `class`, `term`, `adNo`, `ca1`, `ca2`, `exams`, `total`) VALUES
(14, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(15, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(16, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(17, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(18, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(19, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(20, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(21, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(22, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(23, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(24, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(25, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(26, '2021/2022', 'MATHJ1S', 'Mathematics', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(27, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(28, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(29, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(30, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(31, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(32, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(33, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(34, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(35, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(36, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(37, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(38, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(39, '2021/2022', 'ENGJ1S', 'English', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(40, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(41, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(42, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(43, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(44, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(45, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(46, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(47, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(48, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(49, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(50, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(51, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(52, '2021/2022', 'PHEJ1S', 'Physical Health Education', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(53, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(54, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(55, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(56, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(57, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(58, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(59, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(60, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(61, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(62, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(63, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(64, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(65, '2021/2022', 'CEJ1S', 'Civic Education', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(105, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(106, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(107, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(108, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(109, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(110, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(111, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(112, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(113, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(114, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(115, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(116, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(117, '2021/2022', 'BSJ1S', 'Basic Science', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(118, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(119, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(120, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(121, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(122, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(123, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(124, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(125, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(126, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(127, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(128, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(129, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(130, '2021/2022', 'ASJ1S', 'Agricultural Science', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(131, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(132, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(133, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(134, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(135, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(136, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(137, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(138, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(139, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(140, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(141, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(142, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(143, '2021/2022', 'IRSJ1S', 'Islamic Religious studies', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(144, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(145, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(146, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(147, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(148, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(149, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(150, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(151, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(152, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(153, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(154, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(155, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(156, '2021/2022', 'SSJ1S', 'Social Studies', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(157, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(158, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(159, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(160, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(161, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(162, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(163, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(164, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(165, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(166, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(167, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(168, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(169, '2021/2022', 'BTJ1S', 'Basic Technology', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(170, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(171, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(172, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(173, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(174, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(175, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(176, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(177, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(178, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(179, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(180, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(181, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(182, '2021/2022', 'CSJ1S', 'Computer Studies', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(183, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(184, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(185, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(186, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(187, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(188, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(189, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(190, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(191, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(192, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(193, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(194, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(195, '2021/2022', 'HEJ1S', 'Home Economics', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47),
(196, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0001', 21, 21, 61, 103),
(197, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0002', 15, 13, 15, 43),
(198, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0003', 10, 40, 12, 62),
(199, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0004', 22, 36, 56, 114),
(200, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0005', 15, 17, 48, 80),
(201, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0006', 12, 22, 33, 67),
(202, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0007', 14, 20, 23, 57),
(203, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0008', 22, 32, 23, 77),
(204, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0009', 20, 20, 30, 70),
(205, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0010', 23, 34, 23, 80),
(206, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0011', 34, 43, 32, 109),
(207, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0012', 23, 45, 43, 111),
(208, '2021/2022', 'SPJ1S', 'Spelling', 'JSS 1', 2, 'TB/22/0013', 20, 12, 15, 47);

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `id` int(5) NOT NULL,
  `session` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `session`) VALUES
(30, '2021/2022');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_class`
--

CREATE TABLE `tbl_class` (
  `class_id` int(10) NOT NULL,
  `class_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_class`
--

INSERT INTO `tbl_class` (`class_id`, `class_name`) VALUES
(27, 'JSS 1'),
(28, 'JSS 2'),
(29, 'JSS 3'),
(16, 'kindergerten 1'),
(17, 'kindergerten 2'),
(30, 'nursery 1'),
(31, 'nursery 2'),
(18, 'primary 1'),
(19, 'primary 2'),
(21, 'primary 3'),
(22, 'primary 4'),
(25, 'primary 5'),
(26, 'primary 6');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `id` int(11) NOT NULL,
  `adNo` varchar(20) NOT NULL,
  `fName` varchar(20) DEFAULT NULL,
  `mName` varchar(20) DEFAULT NULL,
  `lName` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `gName` varchar(50) DEFAULT NULL,
  `mothersName` varchar(50) DEFAULT NULL,
  `gRelation` varchar(20) DEFAULT NULL,
  `gPhone` varchar(13) DEFAULT NULL,
  `cAdmitted` varchar(10) DEFAULT NULL,
  `cClass` varchar(10) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `yAdmitted` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`id`, `adNo`, `fName`, `mName`, `lName`, `gender`, `dob`, `gName`, `mothersName`, `gRelation`, `gPhone`, `cAdmitted`, `cClass`, `address`, `yAdmitted`) VALUES
(107, 'TB/22/0001', 'Abdull', 'Haruna', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwau Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(108, 'TB/22/0002', 'Abdull', 'Bashir', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwau Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(95, 'TB/22/0003', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(96, 'TB/22/0004', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(109, 'TB/22/0005', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(98, 'TB/22/0006', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(99, 'TB/22/0007', 'Abdull', 'Ibrahim', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(100, 'TB/22/0008', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(101, 'TB/22/0009', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(102, 'TB/22/0010', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(103, 'TB/22/0011', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(104, 'TB/22/0012', 'Abdull', '', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(105, 'TB/22/0013', 'Abdull', 'Tahir', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022'),
(106, 'TB/22/0014', 'Abdull', 'Tahir', 'Yahuza', 'male', '27/12/1994', '', '', '', '', '', '', '', ''),
(110, 'TB/22/0015', 'Abdull', 'Tahir', 'Yahuza', '', '', '', '', '', '', '', '', '', ''),
(111, 'TB/22/0020', 'Abdull', 'Tahir', 'Yahuza', 'male', '27/12/1994', 'Yahuza Haruna', 'Hauwa\'u Abubakar', 'father', '08099999999', 'jss 1', 'jss 1', '84 kachia Kaduna', '2022');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject`
--

CREATE TABLE `tbl_subject` (
  `id` int(5) NOT NULL,
  `class` varchar(30) NOT NULL,
  `subject_code` varchar(15) NOT NULL,
  `staff_username` varchar(50) NOT NULL,
  `term` varchar(25) NOT NULL,
  `session` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_subject`
--

INSERT INTO `tbl_subject` (`id`, `class`, `subject_code`, `staff_username`, `term`, `session`) VALUES
(22, 'JSS 1', 'ASJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(18, 'JSS 1', 'BSJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(19, 'JSS 1', 'BTJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(10, 'JSS 1', 'CEJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(24, 'JSS 1', 'CSJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(6, 'JSS 1', 'ENGJ1S', 'tahirjamilu', 'Second Term', '2021/2022'),
(21, 'JSS 1', 'HEJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(23, 'JSS 1', 'IRSJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(1, 'JSS 1', 'MATHJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(9, 'JSS 1', 'PHEJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(17, 'JSS 1', 'SPJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022'),
(20, 'JSS 1', 'SSJ1S', 'yahuzaabdulrazak', 'Second Term', '2021/2022');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher`
--

CREATE TABLE `tbl_teacher` (
  `id` int(11) NOT NULL,
  `fName` varchar(30) NOT NULL,
  `mName` varchar(30) DEFAULT NULL,
  `lName` varchar(30) NOT NULL,
  `staff_username` varchar(50) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(70) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_teacher`
--

INSERT INTO `tbl_teacher` (`id`, `fName`, `mName`, `lName`, `staff_username`, `phone`, `email`, `address`, `gender`, `dob`, `class`) VALUES
(38, 'Abdulrazak', 'Haruna', 'Yahuza', 'yahuzaabdulrazak', '08099337676', 'yahuzaabdulrazak@gmail.com', '84 kachia by abuja road rigasa kaduna.', 'female', '27/12/1994', 'JSS 1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE `tbl_term` (
  `term_id` int(10) NOT NULL,
  `term` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`term_id`, `term`) VALUES
(1, 'First Term'),
(2, 'Second Term'),
(3, 'Third Term');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_subject`
--
ALTER TABLE `add_subject`
  ADD PRIMARY KEY (`add_subid`),
  ADD UNIQUE KEY `subject_name` (`subject_name`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sesh2021_2022`
--
ALTER TABLE `sesh2021_2022`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_index` (`adNo`,`subject_code`,`class`,`session`,`term`),
  ADD KEY `session` (`session`),
  ADD KEY `term` (`term`),
  ADD KEY `subject_code` (`subject_code`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`session`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tbl_class`
--
ALTER TABLE `tbl_class`
  ADD PRIMARY KEY (`class_id`),
  ADD UNIQUE KEY `class_name` (`class_name`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`adNo`),
  ADD UNIQUE KEY `addNo` (`adNo`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  ADD PRIMARY KEY (`subject_code`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `class` (`class`,`subject_code`,`staff_username`);

--
-- Indexes for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_username` (`staff_username`),
  ADD KEY `class` (`class`);

--
-- Indexes for table `tbl_term`
--
ALTER TABLE `tbl_term`
  ADD PRIMARY KEY (`term_id`),
  ADD UNIQUE KEY `term` (`term`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_subject`
--
ALTER TABLE `add_subject`
  MODIFY `add_subid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sesh2021_2022`
--
ALTER TABLE `sesh2021_2022`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `session`
--
ALTER TABLE `session`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_class`
--
ALTER TABLE `tbl_class`
  MODIFY `class_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_term`
--
ALTER TABLE `tbl_term`
  MODIFY `term_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sesh2021_2022`
--
ALTER TABLE `sesh2021_2022`
  ADD CONSTRAINT `sesh2021_2022_ibfk_1` FOREIGN KEY (`session`) REFERENCES `session` (`session`),
  ADD CONSTRAINT `sesh2021_2022_ibfk_2` FOREIGN KEY (`term`) REFERENCES `tbl_term` (`term_id`),
  ADD CONSTRAINT `sesh2021_2022_ibfk_3` FOREIGN KEY (`adNo`) REFERENCES `tbl_student` (`adNo`) ON DELETE CASCADE,
  ADD CONSTRAINT `sesh2021_2022_ibfk_4` FOREIGN KEY (`subject_code`) REFERENCES `tbl_subject` (`subject_code`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  ADD CONSTRAINT `tbl_teacher_ibfk_1` FOREIGN KEY (`class`) REFERENCES `tbl_class` (`class_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
